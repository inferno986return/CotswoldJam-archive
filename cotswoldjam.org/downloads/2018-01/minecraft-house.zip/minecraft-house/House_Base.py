#!/usr/bin/env python3
from mcpi.minecraft import Minecraft
from mcpi import block

# Connect to Minecraft
mc = Minecraft.create()

# Determine the Player's current position.
x,y,z = mc.player.getTilePos()

width = 5
height = 3
depth = 6

# Create a hollow shell made of bricks.

# Set the floor.

# Add a Door.

# Add Windows.

# Add a Roof.
