#!/usr/bin/env python3
# (C) Steve Martin, 2019

from mcpi.minecraft import Minecraft
from mcpi import block

mc = Minecraft.create()

mc.postToChat("Hello Mincraft")
