from gpiozero import LED
from time import sleep

red=LED(14)
red.on()
sleep(0.5)
