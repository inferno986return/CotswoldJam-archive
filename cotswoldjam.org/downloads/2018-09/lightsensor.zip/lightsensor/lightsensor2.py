from gpiozero import LightSensor, LED
from time import sleep
sensor=LightSensor(18)
led=LED(25)
sensor.threshold=0.1
while True:
  print (sensor.value)
  if ( sensor.light_detected ):
    led.off()
  else:
    led.on()
  sleep(0.2)
