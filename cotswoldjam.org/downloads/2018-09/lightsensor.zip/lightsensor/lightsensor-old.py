# Set up GPIO using the old method before we had GPIOZero
import RPi.GPIO as GPIO
from time import time,sleep
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
sensor=18

while True:
  # Make sure the capacitor is fully discharged
  # Make pin 18 an output and set it to low voltage
  GPIO.setup(sensor, GPIO.OUT)
  GPIO.output(sensor, GPIO.LOW)
  # Give it a hundredth of a second to fully discharge
  sleep(0.01)

  # Make pin 18 an input and count how long it takes to stop being low
  GPIO.setup(sensor, GPIO.IN)
  # Count how long it takes to charge back up again
  # More light = faster charge
  start=time()
  while (GPIO.input(sensor) == GPIO.LOW):
    # The pass command literally does nothing
    # We use it to wait while the sensor is low
    pass

  end=time()
  # Print the time taken, to 3 decimal places
  print ("{0:.3f}".format(end-start))
