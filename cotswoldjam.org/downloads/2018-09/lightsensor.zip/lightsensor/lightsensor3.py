from gpiozero import LightSensor, PWMLED
from time import sleep
sensor=LightSensor(18)
led=PWMLED(25)
sensor.threshold=0.1
while True:
  print (sensor.value)
  if ( sensor.value <= 0.1 ):
    led.value=1
  if ( sensor.value > 0.1 and sensor.value < 0.3 ):
    led.value=0.5
  if ( sensor.value >= 0.3 ):
    led.value=0
  sleep(0.2)
