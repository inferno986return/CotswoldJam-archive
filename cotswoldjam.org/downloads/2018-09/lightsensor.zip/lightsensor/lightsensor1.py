from gpiozero import LightSensor
from time import sleep
sensor=LightSensor(18)
while True:
  print (sensor.value)
  sleep(0.2)
