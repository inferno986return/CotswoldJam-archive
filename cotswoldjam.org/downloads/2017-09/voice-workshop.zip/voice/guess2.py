#/usr/bin/python3
import random, os

def say(input):
  os.system("pico2wave -w output.wav \"{}\" && aplay -q output.wav".format(input))

say ("I am thinking of a number from 1 to 99.")
mynum=random.randint(1,99)

while True:
  say("Type your guess and press Enter: ")
  guess=input (">: ")
  if not guess.isdigit() :
    say ("That wasn't a number. Try again.")
    continue
  guess=int(guess)
  if guess<1 or guess>99 :
    say ("That wasn't a number from 1 to 99. Try again.")
    continue
  if guess==mynum :
    say ("Well done! You guessed my number.")
    break
  if guess>mynum :
    say ("My number is lower.")
  if guess<mynum :
    say ("My number is higher.")

