#!/usr/bin/env python
#    export GOOGLE_APPLICATION_CREDENTIALS=service-key.json # Your Google voice service key
#    python transcribe.py resources/audio.raw

import argparse, io, os
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "voice-workshop-key.json"

def transcribe_file(speech_file):
    from google.cloud import speech
    from google.cloud.speech import enums
    from google.cloud.speech import types
    client = speech.SpeechClient()
    return_value = ""

    with io.open(speech_file, 'rb') as audio_file:
        content = audio_file.read()

    audio = types.RecognitionAudio(content=content)
    config = types.RecognitionConfig(
        encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=44100,
        language_code='en-GB')

    response = client.recognize(config, audio)
    for result in response.results:
        return_value=result.alternatives[0].transcript
    return (return_value)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        'path', help='Audio file to be recognised')
    args = parser.parse_args()
    print (transcribe_file(args.path));
