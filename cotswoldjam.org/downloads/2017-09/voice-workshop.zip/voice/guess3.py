#/usr/bin/python3
import random, os, transcribe

def say(input):
  os.system("pico2wave -w output.wav \"{}\" && aplay -q output.wav".format(input))

def listen(filename,seconds=3):
  os.system("arecord -q -f cd -c 1 -D hw:1,0 -d {} '{}'".format(seconds,filename))

say ("I am thinking of a number from 1 to 99.")
mynum=random.randint(1,99)

while True:
  say ("Say your guess: ")

  listen ("recording.wav")
  say ("I'm thinking...")
  guess=transcribe.transcribe_file("recording.wav")
  if guess=="" :
    say ("I didn't hear you. Try again.")
    continue
  if not guess.isdigit() :
    say ("I think you said: {}".format(guess))
    say ("That's not a number. Try again.")
    continue
  
  guess=int(guess)
  if guess<1 or guess>99 :
    say ("That's not a number from 1 to 99. Try again.")
    continue
  if guess==mynum :
    say ("Well done! You guessed my number.")
    break
  if guess>mynum :
    say ("My number is lower.")
  if guess<mynum :
    say ("My number is higher.")

