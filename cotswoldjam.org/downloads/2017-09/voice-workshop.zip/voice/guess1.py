#/usr/bin/python3
import random

print ("I am thinking of a number from 1 to 99.")
mynum=random.randint(1,99)

while True:
  guess=input ("Type your guess and press Enter: ")
  if not guess.isdigit() :
    print ("That wasn't a number. Try again.")
    continue
  guess=int(guess)
  if guess<1 or guess>99 :
    print ("That wasn't a number from 1 to 99. Try again.")
    continue
  if guess==mynum :
    print ("Well done! You guessed my number.")
    break
  if guess>mynum :
    print ("My number is lower.")
  if guess<mynum :
    print ("My number is higher.")

