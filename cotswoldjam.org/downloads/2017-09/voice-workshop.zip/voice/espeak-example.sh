#!/bin/bash
espeak -ven-gb -k5 -s150 "Shall we play a game?"
