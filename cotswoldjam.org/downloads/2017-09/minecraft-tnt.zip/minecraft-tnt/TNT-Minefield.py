#!/usr/bin/env python3
from mcpi.minecraft import Minecraft
from mcpi import block

mc = Minecraft.create()

x,y,z = mc.player.getTilePos()

for i in range(0, 20, 2):
    for j in range(0, 20, 2):
        h = mc.getHeight(x+i, z+j)
        mc.setBlock(x+i, h-1, z+j, block.TNT.id, 1)
