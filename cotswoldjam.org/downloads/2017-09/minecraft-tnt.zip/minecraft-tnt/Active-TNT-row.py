#!/usr/bin/env python3

from mcpi.minecraft import Minecraft
from mcpi import block

mc = Minecraft.create()

x,y,z = mc.player.getTilePos()

for d in range(10):
  mc.setBlock(x+3+d, y, z, block.TNT.id, 1)
  # When might the following line of code be necessary?
  #mc.setBlock(x+3+d, y-1, z, block.STONE.id)
