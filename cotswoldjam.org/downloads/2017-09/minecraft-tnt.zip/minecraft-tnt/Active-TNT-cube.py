#!/usr/bin/env python3

from mcpi.minecraft import Minecraft
from mcpi import block

mc = Minecraft.create()

x,y,z = mc.player.getTilePos()

mc.setBlocks(x+3, y, z, x+6, y+3, z+3, block.TNT.id, 1)
