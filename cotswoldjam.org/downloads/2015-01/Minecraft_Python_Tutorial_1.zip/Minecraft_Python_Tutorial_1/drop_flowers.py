#!/usr/bin/env python
#############################################
#
# Leave a trail of flowers behind Player.
#
#############################################
from mcpi import minecraft
from mcpi import block
from time import sleep

mc = minecraft.Minecraft.create()

print "Dropping flowers..."

while True:
    x, y, z = mc.player.getPos()
    mc.setBlock(x, y, z, block.FLOWER_YELLOW.id)
    sleep(0.2)


###############################
#
# Exercises:
#    Easy:
#        Leave a trail of something else, like Torches, or a brick road.
#    Medium:
#        Only leave a trail of flowers when walking on grass.


