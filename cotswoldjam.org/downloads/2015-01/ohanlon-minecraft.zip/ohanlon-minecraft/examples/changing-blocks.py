import mcpi.minecraft as minecraft
import mcpi.block as block
import time

mc = minecraft.Minecraft.create()

playerTilePos = mc.player.getTilePos()
mc.setBlock(playerTilePos.x, playerTilePos.y - 1, playerTilePos.z, block.DIAMOND_BLOCK.id)

