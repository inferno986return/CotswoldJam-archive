#!/usr/bin/env python
##################################################
#
# Trigger an action when a magic block is hit (right-click).
#
##################################################
from mcpi import minecraft
from mcpi import block
from time import sleep

mc = minecraft.Minecraft.create()

# For ease of this demo, we're going to put the magic block near the player.
x, y, z = mc.player.getTilePos()

# Define the location of our magic block.
magicX = x
magicZ = z+10
magicY = mc.getHeight(magicX, magicZ)

# Place our magic block so that we can see it.
mc.setBlock(magicX, magicY, magicZ, block.WOOD.id)

print("Waiting for Player to hit (right-click) the magic block.")
print("Pres Ctrl-C to quit.")

# Now we're going to wait for the player to hit the block.
while True:
    sleep(0.5)
    blockEvents = mc.events.pollBlockHits()
    for blockEvent in blockEvents:
        eventX, eventY, eventZ = blockEvent.pos
        if (magicX == eventX and magicY == eventY and magicZ == eventZ):
            # The player has hit our magic block, do something:
            print("Magic block hit on face " + str(blockEvent.face))
            # Remove the block at its current position.
            mc.setBlock(magicX, magicY, magicZ, block.AIR.id)
            # Move the block away from the block face that was hit.
            if (blockEvent.face == 2):
                magicZ += 1
            elif (blockEvent.face == 3):
                magicZ -= 1
            elif (blockEvent.face == 4):
                magicX += 1
            elif (blockEvent.face == 5):
                magicX -= 1
            # Determine the terrain height at the new block location.
            magicY = mc.getHeight(magicX, magicZ)
            # Create the block at its new location.
            mc.setBlock(magicX, magicY, magicZ, block.WOOD.id)


##################################
# Exercises:
#    Easy:
#        Make the block move towards the player then it is hit.
#    Medium:
#        Make something happen when the top of the block is hit.
#    Advanced:
#        Make a random selection of blocks in the world "Magic".
#        (Think about how to make it quite likely that the player will
#        hit one).

