#!/usr/bin/env python
##################################################
#
# Create a flat area of grassland around player.
#
##################################################
from mcpi import minecraft
from mcpi import block

width = 10
length = 10

mc = minecraft.Minecraft.create()

x, y, z = mc.player.getTilePos()
print "Making land at: " + str(x) + ", " + str(z)

mc.setBlocks(x-(width/2), y-1, z-(length/2), x+(width/2), y-1, z+(length/2), block.GRASS.id)
mc.setBlocks(x-(width/2), y, z-(length/2), x+(width/2), y+20, z+(length/2), block.AIR.id)

#############################
#
# Exercises:
#    Easy:
#        Change the type of land that is made.
#        Change the area of land that is made.


