#!/usr/bin/env python
#########################################################
#
# Build a castle wall in Minecraft.
#
#########################################################
from mcpi import minecraft
from mcpi import block

length = 10    # How long should each side of the wall be.
height = 5     # How High should the Castle be.

# Connect to Minecraft
mc = minecraft.Minecraft.create()

# Find out where the Player is (we want to build the wall around them)
x, y, z = mc.player.getTilePos()
print "Making Castle Wall around: " + str(x) + ", " + str(z)

# Build each side of the wall:
for layer in range(height):
    for position in range(length):
        # Set Brick type for position:
        if (layer == 0):
            currentBlock = block.Block(block.MOSS_STONE)
        elif (layer%3 == 2 and position%5 == 2):
            currentBlock = block.Block(block.AIR)
        elif (layer%5 == 1 and position%4 == 2):
            currentBlock = block.Block(block.GLOWSTONE_BLOCK)
        elif (layer == height-1 and position%2 == 0):
            currentBlock = block.Block(block.AIR)
        else:
            currentBlock = block.Block(block.STONE_BRICK.id, 3)

        # Build each of the four walls
        mc.setBlock(x-length/2+position, y+layer, z-length/2, currentBlock)
        mc.setBlock(x-length/2+position, y+layer, z+length/2, currentBlock)
        mc.setBlock(x-length/2, y+layer, z-length/2+position, currentBlock)
        mc.setBlock(x+length/2, y+layer, z-length/2+position, currentBlock)


###########################
# Exercises:
#    Easy:
#        Change the Size and Material that the Castle Walls are made of.
#        Change the location of the windows in the Castle walls.
#    Medium:
#        Place other items in the Castle Wall.
#    Advanced:
#        Create a Moat around the Castle.
