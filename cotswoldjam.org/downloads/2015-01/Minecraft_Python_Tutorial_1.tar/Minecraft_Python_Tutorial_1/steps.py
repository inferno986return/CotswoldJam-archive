#!/usr/bin/env python
#########################################################
#
# Build a flight of steps in Minecraft.
#
#########################################################
from mcpi import minecraft
from mcpi import block

# How many stairs to be made.
size = 10

# Connect to Minecraft
mc = minecraft.Minecraft.create()

# Find out where the Player is (we want to build near here)
x, y, z = mc.player.getTilePos()
print "Making Steps at: " + str(x + 2) + ", " + str(z)

# Build a series of staggered bricks.
for step in range(size):
    mc.setBlock(x+step+2, y+step, z, block.STAIRS_WOOD.id, 0)
    mc.setBlock(x+step+3, y+step, z, block.WOOD.id)


###########################
# Exercises:
#    Easy:
#        Change the Size and Material that the Steps are made of.
#        Change the Width of the steps.
#    Medium:
#        Change the location of the Pyramid relative to the player.
#        Change the direction that the steps go in.
#        Place a platform at the top of the Steps.
#    Advanced:
#        Build a wall or banister either side of the steps.


