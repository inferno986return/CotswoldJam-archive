#!/usr/bin/env python
#######################################################
#
# Build a Pyramid of bricks in Minecraft.
#
#######################################################
from mcpi import minecraft
from mcpi import block

# What will the Pyramid look like:
size = 15

# Connect to Minecraft
mc = minecraft.Minecraft.create()

# Find out where the Player is (we want to build near here)
x, y, z = mc.player.getTilePos()
print "Making Pyramid at: " + str(x + size + 2) + ", " + str(z)

# Build a layer of bricks, making each layer smaller.
for layer in range(size/2+1):
    mc.setBlocks(x+2+layer, y+layer, z+layer, x+size+2-layer, y+layer, z+size-layer, block.MOSS_STONE.id)


##############################
# Exercises:
#    Easy:
#        Change the Size and Material that the Pyramid is made of.
#    Medium:
#        Change the location of the Pyramid relative to the player.
#        Use a different Materal for each layer.
#        Place a Torch on top of the Pyramid.
#    Advanced:
#        Build a hollow Pyramid.
