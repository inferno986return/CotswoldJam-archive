#!/usr/bin/env python
##################################################
#
# Trigger an action when a Player steps on a magic block.
#
##################################################
from mcpi import minecraft
from mcpi import block
from time import sleep

mc = minecraft.Minecraft.create()

# For ease of this demo, we're going to put the magic block near the player.
x, y, z = mc.player.getTilePos()

# Determine the location of the magic block.
magicX = x
magicZ = z+10
magicY = mc.getHeight(magicX, magicZ) - 1

# Also, for this demo, we're going to change the magic block so that we can see it.
mc.setBlock(magicX, magicY, magicZ, block.WOOD.id)

print("Waiting for the Player to find the magic block.")
print("Pres Ctrl-C to quit.")

# Now we're going to wait for the player to step on it.
while True:
    sleep(0.2) # We don't want to hog all the CPU
    px, py, pz = mc.player.getTilePos()
    if (magicX == px and magicZ == pz):
        # The player has stepped on our magic block, do something:
        mc.postToChat("I'm not going to let you pass!")
        mc.player.setTilePos(px, py, pz+5)


##################################
# Exercises:
#    Easy:
#        Leave the magic block in its original style.
#        Build something when the magic block is hit.
#    Medium:
#        Prevent the player from being able to walk around the magic block.
#    Advanced:
#        Make a random selection of blocks in the world "Magic".
#        (Think about how to make it quite likely that the player will
#        land on one).

