#!/usr/bin/python3
import board, neopixel, time
pixels = neopixel.NeoPixel(board.D18, 3, auto_write=False, pixel_order=neopixel.RGB)
pixels.fill((0, 0, 0))
pixels.show()
