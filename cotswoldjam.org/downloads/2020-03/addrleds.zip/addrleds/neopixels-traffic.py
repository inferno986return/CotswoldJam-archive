import board, neopixel, time
pixels = neopixel.NeoPixel(board.D18, 3, auto_write=False, pixel_order=neopixel.RGB)

while True:
  pixels[0] = (255, 0, 0)
  pixels[1] = (0, 0, 0)
  pixels[2] = (0, 0, 0)
  pixels.show()
  time.sleep(10)

  pixels[0] = (255, 0, 0)
  pixels[1] = (255, 255, 0)
  pixels[2] = (0, 0, 0)
  pixels.show()
  time.sleep(2)

  pixels[0] = (0, 0, 0)
  pixels[1] = (0, 0, 0)
  pixels[2] = (0, 255, 0)
  pixels.show()
  time.sleep(14)

  pixels[0] = (0, 0, 0)
  pixels[1] = (255, 255, 0)
  pixels[2] = (0, 0, 0)
  pixels.show()
  time.sleep(3)
