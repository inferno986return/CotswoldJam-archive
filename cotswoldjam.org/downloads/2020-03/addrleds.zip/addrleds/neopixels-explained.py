#!/usr/bin/python3
# To set everything up in Raspbian Buster:
#   Raspberry menu - Preferences - Raspberry pi configuration - SPI enable - I2C enable
#   Raspberry menu - Shutdown - Reboot
# Then install the libraries:
#   sudo pip3 install rpi_ws281x adafruit-circuitpython-neopixel
# Note that you may need to use sudo to run programs using the neopixel library
# You can manage without sudo by just using rpi_ws281x, but it's not as easy as neopixel

import board, neopixel, time

# Our strip is on pin 18
# There are 3 LED in our strip
# Don't automatically update the pixels without the show() command
# Colours are in Red Green Blue order (some strips use GRB)
pixels = neopixel.NeoPixel(board.D18, 3, auto_write=False, pixel_order=neopixel.RGB)

pixels[0] = (255, 0, 0)
pixels[1] = (0, 255, 0)
pixels[2] = (0, 0, 255)
pixels.show()

time.sleep(2)

pixels.fill((0, 0, 0))
pixels.show()
