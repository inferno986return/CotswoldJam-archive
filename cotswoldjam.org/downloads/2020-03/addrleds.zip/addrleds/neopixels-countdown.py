#!/usr/bin/python3
import board, neopixel, time
pixels = neopixel.NeoPixel(board.D18, 3, auto_write=False, pixel_order=neopixel.RGB)

# Count 20 seconds for washing our hands!

# Start with pixels off
pixels.fill((0, 0, 0))
pixels.show()

# First 5 seconds are red - count three forward
# Notice how we start counting from zero
# and stop before we reach 3
for x in range(0,3):
  pixels.fill((0, 0, 0))
  pixels[x] = (255, 0, 0)
  pixels.show()
  time.sleep(1)

# Now count two back
# We start at 1
# and stop before we reach -1
# and count -1 each time
for x in range(1,-1,-1):
  pixels.fill((0, 0, 0))
  pixels[x] = (255, 0, 0)
  pixels.show()
  time.sleep(1)

# Next 5 seconds are yellow
for x in range(0,3):
  pixels.fill((0, 0, 0))
  pixels[x] = (255, 255, 0)
  pixels.show()
  time.sleep(1)
for x in range(1,-1,-1):
  pixels.fill((0, 0, 0))
  pixels[x] = (255, 255, 0)
  pixels.show()
  time.sleep(1)

# Next 5 seconds are green
for x in range(0,3):
  pixels.fill((0, 0, 0))
  pixels[x] = (0, 255, 0)
  pixels.show()
  time.sleep(1)
for x in range(1,-1,-1):
  pixels.fill((0, 0, 0))
  pixels[x] = (0, 255, 0)
  pixels.show()
  time.sleep(1)

# Final 5 seconds are blue
for x in range(0,3):
  pixels.fill((0, 0, 0))
  pixels[x] = (0, 0, 255)
  pixels.show()
  time.sleep(1)
for x in range(1,-1,-1):
  pixels.fill((0, 0, 0))
  pixels[x] = (0, 0, 255)
  pixels.show()
  time.sleep(1)

# Finish with pixels off
pixels.fill((0, 0, 0))
pixels.show()
