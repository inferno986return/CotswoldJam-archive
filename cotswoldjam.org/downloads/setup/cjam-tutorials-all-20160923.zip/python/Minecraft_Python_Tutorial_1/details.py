#!/usr/bin/env python
##############################################
#
# Show details for the Minecraft Player
#
##############################################
from mcpi import minecraft

mc = minecraft.Minecraft.create()

pos = mc.player.getPos()

mc.postToChat("Hi Minecreft API, this message is from Python.")

print "You are at: " + str(pos.x) + ", " + str(pos.z) + ", " + str(pos.y)
print "Standing in: " + str(mc.getBlock(pos))
print "Standing on: " + str(mc.getBlock(pos.x, pos.y-1, pos.z))
