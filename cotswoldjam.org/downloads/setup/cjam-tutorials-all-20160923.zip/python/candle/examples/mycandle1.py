#!/usr/bin/env python

import RPi.GPIO as GPIO, time, os

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
pin_write=7

GPIO.setup(pin_write, GPIO.OUT)
GPIO.output(pin_write, GPIO.HIGH)
time.sleep(2)
GPIO.output(pin_write, GPIO.LOW)

