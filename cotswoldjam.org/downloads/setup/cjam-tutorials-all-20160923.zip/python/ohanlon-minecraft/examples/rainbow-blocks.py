import mcpi.minecraft as minecraft
import mcpi.block as block
import time
import random

mc = minecraft.Minecraft.create()

while (True):
  playerTilePos = mc.player.getTilePos()
  woolColour = random.randrange(0,15)
  mc.setBlock(playerTilePos.x, playerTilePos.y - 1, playerTilePos.z, block.WOOL.id, woolColour)
  
