import mcpi.minecraft as minecraft
import mcpi.block as block
import time

mc = minecraft.Minecraft.create()

mc.postToChat("Hello Minecraft World")

time.sleep(5)
