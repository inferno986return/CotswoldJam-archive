# SenseHAT demo by Andrew Oakley 2016 Public Domain

# Import the required libraries
from sense_hat import SenseHat
from time import sleep
sense = SenseHat()

# Set the display to all dark blue
sense.clear((0,0,64))

# Brief pause before we start taking baseline readings
sleep(0.1)

# Make some baseline readings for comparisons
baseline_temperature=sense.get_temperature()
baseline_humidity=sense.get_humidity()
baseline_pressure=sense.get_pressure()

# Brief pause before we start taking more readings
sleep(0.1)

# Keep going until someone presses CTRL-C or there is an error
try:
  while True:

    # Print a blank line to make output easier to read
    print()

    # Get the temperature and assign it a value between 1 and 6
    # Assumes active range is -5 to +30 celcius
    # Try gently putting a warm finger on the humidity sensor
    temperature=sense.get_temperature()
    print ("Temperature: %8.3f C" % temperature)
    temprange=int((temperature-baseline_temperature)*2)+2
    if temprange<1:
      temprange=1
    if temprange>6:
      temprange=6

    # Get the humidity and assign it a value between 1 and 6
    # Assumes active range is no more than 30 percentage points above baseline
    # Try breathing gently on the humidity sensor
    humidity=sense.get_humidity()
    print ("Humidity   : %8.3f" % humidity)
    humidrange=int((humidity-baseline_humidity)/6)+2
    if humidrange<1:
      humidrange=1
    if humidrange>6:
      humidrange=6

    # Get the pressure and assign it a value between 1 and 6
    # Assumes active range is no more than 24 mBar above baseline
    # Put the Pi in a plastic bag, seal it up as best you can
    # Inflate the bag (e.g. with a straw) and try squeezing the bag
    pressure=sense.get_pressure()
    print ("Pressure   : %8.3f" % pressure)
    pressrange=int((pressure-baseline_pressure)/4)
    if pressrange<1:
      pressrange=1
    if pressrange>6:
      humidrange=6

    # Get the orientation
    # Try tilting the Raspberry Pi
    pitch,yaw,roll=sense.get_orientation().values()
    print ("Pitch      : %8d" % (pitch-180))
    print ("Yaw        : %8d" % (yaw-180))
    print ("Roll       : %8d" % (roll-180))

    # Display some stuff
    # In the middle of the display is a bar chart

    for x in range(1,7):

      # A top bar (red) showing temperature
      if x<=temprange:
        sense.set_pixel(x,1,(255,0,0))
      else:
        sense.set_pixel(x,1,(64,0,0))

      # A middle bar (green) showing humidity
      if x<=humidrange:
        sense.set_pixel(x,3,(0,255,0))
      else:
        sense.set_pixel(x,3,(0,64,0))

      # A bottom bar (yellow) showing pressure
      if x<=pressrange:
        sense.set_pixel(x,5,(255,255,0))
      else:
        sense.set_pixel(x,5,(64,64,0))

      # Edges of the display (blue) show orientation

      # Top and bottom edges
      if pitch-180>45:
        sense.set_pixel(x,0,(0,0,255))
        sense.set_pixel(x,7,(0,0,64))
      elif pitch-180<-45:
        sense.set_pixel(x,0,(0,0,64))
        sense.set_pixel(x,7,(0,0,255))
      else:
        sense.set_pixel(x,0,(0,0,64))
        sense.set_pixel(x,7,(0,0,64))

      # Left and right edges
      if roll-180>45:
        sense.set_pixel(0,x,(0,0,255))
        sense.set_pixel(7,x,(0,0,64))
      elif roll-180<-45:
        sense.set_pixel(0,x,(0,0,64))
        sense.set_pixel(7,x,(0,0,255))
      else:
        sense.set_pixel(0,x,(0,0,64))
        sense.set_pixel(7,x,(0,0,64))

    # Wait quarter of a second before taking the next reading
    sleep (0.25)

# If the program is interrupted, clear the display
# then report the reason for interruption (error)
except:
  sense.clear()
  raise
