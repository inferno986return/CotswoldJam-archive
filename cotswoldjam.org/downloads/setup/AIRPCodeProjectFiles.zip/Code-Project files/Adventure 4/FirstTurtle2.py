import turtle
alex = turtle.Turtle()
alex.shape("turtle")

for i in [0,1,2,3,4,]:
    alex.forward(100)
    alex.left(72)


