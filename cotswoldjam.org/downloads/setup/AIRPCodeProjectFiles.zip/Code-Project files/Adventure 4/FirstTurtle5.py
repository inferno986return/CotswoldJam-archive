import turtle
alex = turtle.Turtle()
alex.color("darkgreen")
alex.pensize(5)
alex.shape("turtle")

print (range(5,100,2))
for size in range (5,100,2):
    alex.forward(size)
    alex.left(25)


