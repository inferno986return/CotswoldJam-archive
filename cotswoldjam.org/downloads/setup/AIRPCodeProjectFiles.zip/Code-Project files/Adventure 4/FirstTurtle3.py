import turtle
alex = turtle.Turtle()
alex.shape("turtle")

for i in range (5):
    alex.forward(100)
    alex.left(72)


