# current_location

# Initialise health points
hp = 30

# Ask for input with the given prompt. Keep retrying until one of the words in 
# the accepted list is given
def get_input(prompt, accepted):
  while True:
    value = input(prompt).lower()
    if value in accepted:
      return value
    else:
      print("That is not a recognised answer, must be one of ", accepted)

# Takes the current location, performs action based on that location and 
# returns the new location
def handle_room(location):
  global hp
  
  if location == "start":
    print("You are standing on a path at the edge of a jungle. There is a cave to your left and a beach to your right")
    direction = get_input("Do you want to go left or right? ", ["left", "right"])
    if direction == "left":
      return "cave"
    elif direction == "right":
      return "beach"

  elif location == "cave":
    print("You walk to the cave and notice there is an opening.")
    print("A small snake bites you, and you lose 20 health points")
    hp = hp - 20

    answer = get_input("Do you want to go deeper?", ["yes", "no"])
    if answer == "yes":
      return "deep_cave"
    else:
      return "start"

  elif location == "beach":
    print("You walk to the beach but remember you do not have any swimwear. Life is a beach")
    print("The cool water revitalizes you. You have never felt more alive, gain 70 health points")
    hp += 70
    return "end"

  else:
    print("Programmer error, room ", location, " is unknown")
    return "end"

# Game loop
location = "start"
# Loop until we reach the special "end" location
while location != "end":
  location = handle_room(location) # update location

  # Check we are not dead each turn
  print("You now have ", hp, "health points")
  if hp <= 0:
    print("You are dead. I am sorry.")
    break

print("Your adventure has ended, goodbye")
