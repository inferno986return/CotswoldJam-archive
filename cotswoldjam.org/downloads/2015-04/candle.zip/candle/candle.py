#!/usr/bin/env python

# Raspberry Pi GPIO Birthday Candles by Andrew Oakley aoakley.com Public Domain 2015
# Adapted from "Basic Photocell Reading" by Adafruit

# Import the libraries we will be using
import RPi.GPIO as GPIO, time, os
# RPi.GPIO - for controlling GPIO pins
# time - for waiting
# os - for calling the music program

# Set up the GPIO
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
pin_read=12 # GPIO 18
pin_write=7 # GPIO 4

# Sensitivity, in percent
sensitivity=50

def timeLowHigh ():
  # This times how long it takes for a pin to go from low to high.
  # It is handy for reading variable resistance using a capacitor.
  # If the capacitor fills slowly, there is high resistance.
  # Photocells are a type of variable resistor. When there is low
  # light, then there is high resistance.
  # Therefore long time = darker, short time = lighter
  # Try using a 1 microfarad capacitor and a 2-20K ohm photocell.

  # Reset the reading to zero
  reading = 0

  # Reset the pin to low - we briefly set it to output
  GPIO.setup(pin_read, GPIO.OUT)
  GPIO.output(pin_read, GPIO.LOW)
  # Brief sleep just to let it settle on low
  time.sleep(0.01)

  # Now change the pin back to an input
  GPIO.setup(pin_read, GPIO.IN)
  # This takes about 1 millisecond per loop cycle
  while (GPIO.input(pin_read) == GPIO.LOW):
    reading += 1

  return reading

def calibrate():
  # This turns on the LED and works out what the
  # "normal" level of dimness is with the LED on.

  # Turn on the LED
  GPIO.setup(pin_write, GPIO.OUT)
  GPIO.output(pin_write, GPIO.HIGH)
  
  # Read the dimness lots of times over 3 seconds
  # and keep a running tally of the average
  print ("Calibrating...")
  dimness=timeLowHigh()
  t=time.time()
  while time.time() < t+2:
    c=timeLowHigh()
    print "   calibration: %05d  now: %05d" % (dimness, c)
    dimness=( dimness+c )/2

  return dimness

# Record what normal dimness is
normal_dimness=calibrate()

while True:
  # Find out what the dimness is now
  dimness_now=timeLowHigh()
  # Print out the values
  print("dimness normal: %05d  now: %05d  target: %05d" % (normal_dimness, dimness_now, normal_dimness*(sensitivity/100.0) ) )

  # Has the dimness fallen below the target?
  if dimness_now < normal_dimness*(sensitivity/100.0) :
    GPIO.output(pin_write, GPIO.LOW)
    print ("Good Morning to All!")
    os.system('omxplayer good-morning-to-all.ogg')
    normal_dimness=calibrate()

