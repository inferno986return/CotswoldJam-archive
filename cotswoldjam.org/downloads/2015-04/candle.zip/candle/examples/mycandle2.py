import RPi.GPIO as GPIO, time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
pin_write=7
pin_read=12

GPIO.setup(pin_write, GPIO.OUT)
GPIO.output(pin_write, GPIO.HIGH)
time.sleep(1)

GPIO.setup(pin_read, GPIO.OUT)
GPIO.output(pin_read, GPIO.LOW)
time.sleep(0.01)
GPIO.setup(pin_read, GPIO.IN)

reading=0
while (GPIO.input(pin_read) == GPIO.LOW):
  reading += 1

print "Reading: %d" % reading

GPIO.output(pin_write, GPIO.LOW)


